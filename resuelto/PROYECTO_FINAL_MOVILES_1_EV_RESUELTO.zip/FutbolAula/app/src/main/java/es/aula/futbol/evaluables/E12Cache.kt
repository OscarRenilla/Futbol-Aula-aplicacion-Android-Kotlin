// EVALUABLE E12 · "Datos guardados sin conexión"
// ============================================================
// LEE PRIMERO docs/E12.md Y EL EJEMPLO X12Cache.kt (ya resuelto).
//
// TU MISIÓN: implementar la función resolve de abajo.
// QUÉ DEBE HACER (el contrato, lo comprueba E12Test y el botón Comprobar):
//   1. Decidir qué catálogo mostrar y con qué mensaje.
//   2. Si la descarga funcionó (remote != null y sin error): mostrar el remoto,
//      stale=false, mensaje "Actualizado".
//   3. Si falló: mostrar los datos GUARDADOS, stale=true (están caducados),
//      con un mensaje claro. Nunca dejar la app sin datos si había guardados.
//   4. Sin red y sin nada guardado: lista vacía con stale=true.
// Sitúa el archivo en el paquete común; la carpeta organiza el material didáctico.
package es.aula.futbol

// Declara el objeto E12Cache: aquí vive tu solución evaluable.
object E12Cache {
 // Decide qué datos mostrar según cómo fue la descarga.
 // ENTRADA: remote = catálogo descargado (null si falló); saved = datos guardados;
 // error = mensaje del fallo (null si todo fue bien).
 // SALIDA: CacheResult con las filas a mostrar, si están caducadas y el mensaje.
 fun resolve(remote: List<Player>?, saved: List<Player>, error: String?): CacheResult {
   // SOLUCIÓN PROPIA: una respuesta válida (aunque esté vacía) es el dato actual; un fallo cae a lo guardado.
  if (remote != null && error == null) {
   val message = if (remote.isEmpty()) "Actualizado: el servidor respondió sin jugadores" else "Actualizado"
   return CacheResult(remote, false, message)
  }
  val reason = error?.takeIf { it.isNotBlank() } ?: "sin respuesta"
  return if (saved.isNotEmpty()) CacheResult(saved, true, "Sin conexión ($reason): mostrando ${saved.size} jugadores guardados")
  else CacheResult(emptyList(), true, "Sin conexión ($reason) y sin datos guardados todavía")
 }
 // demo() lo usa Academia: qué pasa si no hay red y solo están los datos iniciales.
 fun demo(): String = resolve(null,Seed.players,"sin red").message
}
