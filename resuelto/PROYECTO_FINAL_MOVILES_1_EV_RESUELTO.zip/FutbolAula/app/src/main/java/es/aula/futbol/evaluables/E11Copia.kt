// EVALUABLE E11 · "Copia de seguridad validada"
// ============================================================
// LEE PRIMERO docs/E11.md Y EL EJEMPLO X11Copia.kt (ya resuelto).
//
// TU MISIÓN: implementar la función restore de abajo.
// QUÉ DEBE HACER (el contrato, lo comprueba E11Test y el botón Comprobar):
//   1. Leer el TEXTO de una copia en JSON (formato de Wire.encode).
//   2. Quedarse solo con los IDs conocidos: si la copia habla de un jugador
//      que no existe en este móvil, se ignora.
//   3. Si el texto está corrupto o no es JSON: error controlado (nada se rompe).
//   4. Devolver un mapa ID -> Mark SOLO con favorito y nota (la copia v1
//      no incluye etiquetas ni valoración).
// PISTA: Wire.decode(text, known) ya valida el formato; aprovéchalo.
// Sitúa el archivo en el paquete común; la carpeta organiza el material didáctico.
package es.aula.futbol

// Declara el objeto E11Copia: aquí vive tu solución evaluable.
object E11Copia {
 // Lee y valida una copia de seguridad para poder restaurarla.
 // ENTRADA: current = datos actuales; text = texto JSON de la copia;
 // known = IDs que existen en este dispositivo.
 // SALIDA: mapa con los datos recuperables; error si la copia es inválida.
 fun restore(current: Map<Int, Mark>, text: String, known: Set<Int>): Map<Int, Mark> {
   // SOLUCIÓN PROPIA: decode valida TODA la copia (versión, tipos, duplicados, tamaño) antes de tocar nada
  // y lanza excepción si el texto no es JSON; solo después mezclo con los datos actuales.
  val incoming = Wire.decode(text, known)
  val merged = LinkedHashMap(current)
  // La copia sobrescribe favorito y nota de los IDs presentes; el resto (y etiquetas/valoración) se conserva.
  incoming.forEach { (id, mark) -> merged[id] = (current[id] ?: Mark()).copy(favorite = mark.favorite, note = mark.note) }
  return merged
 }
 // demo() lo usa Academia: restaura una copia mínima con un favorito.
 fun demo(): String = restore(emptyMap(),Wire.encode(mapOf(1 to Mark(true,"Nota"))),setOf(1)).toString()
}
