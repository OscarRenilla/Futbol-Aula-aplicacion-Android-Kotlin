# Edición ALUMNO

16 X*.kt resueltos en ejemplos/ y 16 E*.kt en evaluables/.
Los E contienen TODO intencional y no contienen sus algoritmos resueltos. La app base abre y captura los pendientes. Los tests de contratos evaluables serán rojos hasta resolverlos. Empieza por README.md y docs/EMPIEZA_AQUI.md.
Novedades de la edición 2.1: botón "Comprobar E##" en Academia (resultados en color y detalle por caso), comprobación global de los 16, Gradle Wrapper incluido y comentarios reescritos línea a línea. No se ha eliminado ninguna capacidad de la edición anterior.
