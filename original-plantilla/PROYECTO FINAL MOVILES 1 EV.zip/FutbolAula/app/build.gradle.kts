plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "es.aula.futbol"
 compileSdk = 35
 defaultConfig {
  applicationId = "es.aula.futbol"
  minSdk = 26
  targetSdk = 35
  versionCode = 3
  versionName = "2.1"
  testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
 }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 testImplementation("junit:junit:4.13.2")
 testImplementation("org.json:json:20240303")
 androidTestImplementation("androidx.test:core:1.6.1")
 androidTestImplementation("androidx.test:runner:1.6.2")
 androidTestImplementation("androidx.test.ext:junit:1.2.1")
 androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
