// EVALUABLE E03 · "Etiquetas y valoración personal"
// ============================================================
// LEE PRIMERO docs/E03.md Y EL EJEMPLO X03Etiquetas.kt (ya resuelto).
//
// TU MISIÓN: implementar la función mark de abajo.
// QUÉ DEBE HACER (el contrato, lo comprueba E03Test y el botón Comprobar):
//   1. Limpiar la lista de etiquetas: quitar espacios, vacías y repetidas
//      (aunque cambien acentos o mayúsculas: "Técnica" = "tecnica").
//   2. Admitir COMO MÁXIMO 5 etiquetas de hasta 24 caracteres cada una.
//   3. La valoración solo puede ir de 0 a 5; fuera de rango: error.
//   4. Conservar la nota y el favorito que ya tenía la ficha (usa copy).
// PISTA: original.copy(tags = clean, rating = rating) crea la Mark nueva.
// Sitúa el archivo en el paquete común; la carpeta organiza el material didáctico.
package es.aula.futbol

// Declara el objeto E03Etiquetas: aquí vive tu solución evaluable.
object E03Etiquetas {
 // Guarda etiquetas limpias y valoración personal sobre una marca existente.
 // ENTRADA: original = la marca actual; tags = etiquetas escritas por el alumno;
 // rating = valoración personal de 0 a 5.
 // SALIDA: una Mark nueva con las etiquetas y valoración ya validadas.
 fun mark(original: Mark, tags: List<String>, rating: Int): Mark {
  // Punto evaluable sin resolver: implementa el contrato del enunciado; la app captura este aviso.
  TODO("E03 pendiente: consulta docs/E03.md")
 }
 // demo() lo usa Academia: guarda dos etiquetas repetidas y valoración 4.
 fun demo(): String = mark(Mark(),listOf("Técnica"," técnica "),4).toString()
}
