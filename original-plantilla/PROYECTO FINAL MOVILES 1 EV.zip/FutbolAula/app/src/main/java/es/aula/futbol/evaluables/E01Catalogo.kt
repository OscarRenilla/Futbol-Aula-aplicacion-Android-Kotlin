// EVALUABLE E01 · "Más equipos reales"
// ============================================================
// LEE PRIMERO docs/E01.md Y EL EJEMPLO X01Catalogo.kt (ya resuelto).
//
// TU MISIÓN: implementar la función addTeam de abajo.
// QUÉ DEBE HACER (el contrato, lo comprueba E01Test y el botón Comprobar):
//   1. Recibir el catálogo actual y un LOTE nuevo (un solo club, 5+ jugadores).
//   2. Devolver el catálogo actualizado (lista actual + lote).
//   3. RECHAZAR con error: lote vacío, dos clubes mezclados, ID repetido
//      o el mismo jugador duplicado con otro ID.
// REGLAS: no cambies la firma ni borres el TODO hasta terminar.
// El botón "Comprobar E01" de Academia te dirá exactamente qué caso falla.
// Sitúa el archivo en el paquete común; la carpeta organiza el material didáctico.
package es.aula.futbol

// Declara el objeto E01Catalogo: aquí vive tu solución evaluable.
object E01Catalogo {
 // Añade un lote nuevo al catálogo actual, validando todas las reglas.
 // ENTRADA: current = lista actual; incoming = lote nuevo de UN club.
 // SALIDA: la lista actualizada. Si algo no cumple las reglas: error (require).
 fun addTeam(current: List<Player>, incoming: List<Player>): List<Player> {
  // Punto evaluable sin resolver: implementa el contrato del enunciado; la app captura este aviso.
  TODO("E01 pendiente: consulta docs/E01.md")
 }
 // demo() lo usa Academia para probar tu función con el lote del Athletic.
 // Devuelve cuántos jugadores hay tras añadirlo (16 + 5 = 21).
 fun demo(): String = addTeam(Seed.players, Seed.extra).size.toString()
}
